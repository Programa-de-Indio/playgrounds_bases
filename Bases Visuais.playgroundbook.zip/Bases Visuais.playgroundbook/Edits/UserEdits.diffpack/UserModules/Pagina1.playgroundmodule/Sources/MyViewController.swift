import UIKit

public class MyViewController: UIViewController{
    override public func viewDidLoad() {
        self.view.backgroundColor = #colorLiteral(red: 0.9607843137254902, green: 0.7058823529411765, blue: 0.2, alpha: 1.0)
    }
}
