import SpriteKit

public class GameScene: SKScene{
    override public func didMove(to view: SKView) {
        self.backgroundColor = #colorLiteral(red: 0.4666666666666667, green: 0.7647058823529411, blue: 0.26666666666666666, alpha: 1.0)
    }
}
